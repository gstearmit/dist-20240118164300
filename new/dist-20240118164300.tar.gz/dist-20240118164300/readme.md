git clone https://github.com/microsoft/monaco-editor.git
cd monaco-editor
cd samples
npm install .
npm run simpleserver